const gridCanvas = document.getElementById("gridCanvas");
const ctx = gridCanvas.getContext("2d");
const gradientCanvas = document.getElementById("gradientCanvas");
const gctx = gradientCanvas.getContext("2d");

const rows = 20;
const cols = 26;
const cellSize = 30;
const EMPTY = 0;
const WALL = 1;
const START = 2;
const GOAL = 3;
const OPEN = 4;
const CLOSED = 5;
const PATH = 6;
const ROBOT = 7;
const ALLOW_DIAGONALS = true;

const colors = {
  [EMPTY]: "#ffffff",
  [WALL]: "#334155",
  [START]: "#22c55e",
  [GOAL]: "#ef4444",
  [OPEN]: "#60a5fa",
  [CLOSED]: "#f59e0b",
  [PATH]: "#a855f7",
  [ROBOT]: "#111827"
};

let grid = [];
let weights = [];
let currentTool = "wall";
let startNode = { row: 2, col: 2 };
let goalNode = { row: 16, col: 21 };
let isRunning = false;
let isMouseDown = false;
let liveMode = false;
let lastPath = [];
let lastRawPath = [];
let nodesExploredCount = 0;
let currentAlgorithmName = "None";
let gradientSurface = [];
let gradientTrace = [];
let gradientPoint = { x: 60, y: 60 };

function setStatus(message) {
  document.getElementById("status").textContent = message;
}

function setTool(toolName, label) {
  currentTool = toolName;
  document.getElementById("current-tool").textContent = label;

  const map = {
    start: "tool-start",
    goal: "tool-goal",
    wall: "tool-wall",
    erase: "tool-erase",
    weight: "tool-weight"
  };

  Object.values(map).forEach((id) => {
    const btn = document.getElementById(id);
    if (btn) btn.classList.remove("active-tool");
  });

  if (map[toolName]) {
    document.getElementById(map[toolName]).classList.add("active-tool");
  }
}

function updateStats({ explored = 0, pathLength = 0, pathCost = 0, turns = 0, algorithm = "None" } = {}) {
  document.getElementById("nodes-explored").textContent = explored;
  document.getElementById("path-length").textContent = pathLength;
  document.getElementById("path-cost").textContent = pathCost.toFixed ? pathCost.toFixed(2) : pathCost;
  document.getElementById("turn-count").textContent = turns;
  document.getElementById("algorithm-name").textContent = algorithm;
}

function createGrid() {
  grid = Array.from({ length: rows }, () => Array(cols).fill(EMPTY));
  weights = Array.from({ length: rows }, () => Array(cols).fill(1));
  grid[startNode.row][startNode.col] = START;
  grid[goalNode.row][goalNode.col] = GOAL;
  lastPath = [];
  lastRawPath = [];
}

function resetSearchStates() {
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if ([OPEN, CLOSED, PATH, ROBOT].includes(grid[r][c])) {
        grid[r][c] = EMPTY;
      }
    }
  }
  grid[startNode.row][startNode.col] = START;
  grid[goalNode.row][goalNode.col] = GOAL;
}

function clearPathOnly() {
  if (isRunning) return;
  resetSearchStates();
  lastPath = [];
  lastRawPath = [];
  updateStats();
  setStatus("Path cleared.");
  drawGrid();
}

function inBounds(row, col) {
  return row >= 0 && row < rows && col >= 0 && col < cols;
}

function key(node) {
  return `${node.row},${node.col}`;
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function heuristic(a, b) {
  const dx = Math.abs(a.col - b.col);
  const dy = Math.abs(a.row - b.row);
  return ALLOW_DIAGONALS ? Math.hypot(dx, dy) : dx + dy;
}

function getWeightColor(weight) {
  if (weight <= 1) return null;
  if (weight === 2) return "rgba(34, 197, 94, 0.18)";
  if (weight === 3) return "rgba(250, 204, 21, 0.26)";
  if (weight === 4) return "rgba(249, 115, 22, 0.28)";
  return "rgba(239, 68, 68, 0.34)";
}

function drawGrid(robotNode = null) {
  ctx.clearRect(0, 0, gridCanvas.width, gridCanvas.height);
  ctx.shadowBlur = 2;
  ctx.shadowColor = "rgba(0,0,0,0.2)";

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const state = robotNode && robotNode.row === r && robotNode.col === c ? ROBOT : grid[r][c];
      ctx.fillStyle = colors[state];
      ctx.fillRect(c * cellSize, r * cellSize, cellSize, cellSize);

      const overlay = getWeightColor(weights[r][c]);
      if (overlay && ![WALL, START, GOAL, ROBOT].includes(state)) {
        ctx.fillStyle = overlay;
        ctx.fillRect(c * cellSize, r * cellSize, cellSize, cellSize);
      }

      if (weights[r][c] > 1 && state !== WALL) {
        ctx.fillStyle = "#0f172a";
        ctx.font = "12px Arial";
        ctx.fillText(String(weights[r][c]), c * cellSize + 10, r * cellSize + 18);
      }

      ctx.strokeStyle = "#cbd5e1";
      ctx.strokeRect(c * cellSize, r * cellSize, cellSize, cellSize);
    }
  }
}

function getCellFromMouse(event) {
  const rect = gridCanvas.getBoundingClientRect();
  const scaleX = gridCanvas.width / rect.width;
  const scaleY = gridCanvas.height / rect.height;
  const x = (event.clientX - rect.left) * scaleX;
  const y = (event.clientY - rect.top) * scaleY;
  return { row: Math.floor(y / cellSize), col: Math.floor(x / cellSize) };
}

function setWeightAtCell(row, col) {
  if (!inBounds(row, col)) return;
  if ((row === startNode.row && col === startNode.col) || (row === goalNode.row && col === goalNode.col) || grid[row][col] === WALL) {
    return;
  }
  weights[row][col] = weights[row][col] >= 5 ? 1 : weights[row][col] + 1;
}

function applyToolAtCell(row, col) {
  if (!inBounds(row, col) || isRunning) return;

  if (currentTool === "start") {
    grid[startNode.row][startNode.col] = EMPTY;
    startNode = { row, col };
    grid[row][col] = START;
  } else if (currentTool === "goal") {
    grid[goalNode.row][goalNode.col] = EMPTY;
    goalNode = { row, col };
    grid[row][col] = GOAL;
  } else if (currentTool === "wall") {
    if ((row === startNode.row && col === startNode.col) || (row === goalNode.row && col === goalNode.col)) return;
    grid[row][col] = WALL;
    weights[row][col] = 1;
  } else if (currentTool === "erase") {
    if ((row === startNode.row && col === startNode.col) || (row === goalNode.row && col === goalNode.col)) return;
    grid[row][col] = EMPTY;
    weights[row][col] = 1;
  } else if (currentTool === "weight") {
    setWeightAtCell(row, col);
  }

  drawGrid();

  if (liveMode && !isRunning) {
    runAStar();
  }
}

function getNeighbors(node) {
  const directions = ALLOW_DIAGONALS
    ? [
        { dr: -1, dc: 0, cost: 1 },
        { dr: 1, dc: 0, cost: 1 },
        { dr: 0, dc: -1, cost: 1 },
        { dr: 0, dc: 1, cost: 1 },
        { dr: -1, dc: -1, cost: Math.SQRT2 },
        { dr: -1, dc: 1, cost: Math.SQRT2 },
        { dr: 1, dc: -1, cost: Math.SQRT2 },
        { dr: 1, dc: 1, cost: Math.SQRT2 }
      ]
    : [
        { dr: -1, dc: 0, cost: 1 },
        { dr: 1, dc: 0, cost: 1 },
        { dr: 0, dc: -1, cost: 1 },
        { dr: 0, dc: 1, cost: 1 }
      ];

  const neighbors = [];
  for (const d of directions) {
    const nr = node.row + d.dr;
    const nc = node.col + d.dc;
    if (!inBounds(nr, nc) || grid[nr][nc] === WALL) continue;

    if (Math.abs(d.dr) + Math.abs(d.dc) === 2) {
      const adjacentA = { row: node.row + d.dr, col: node.col };
      const adjacentB = { row: node.row, col: node.col + d.dc };
      if (
        inBounds(adjacentA.row, adjacentA.col) &&
        inBounds(adjacentB.row, adjacentB.col) &&
        (grid[adjacentA.row][adjacentA.col] === WALL || grid[adjacentB.row][adjacentB.col] === WALL)
      ) {
        continue;
      }
    }

    neighbors.push({ row: nr, col: nc, moveCost: d.cost * weights[nr][nc] });
  }
  return neighbors;
}

function rebuildPath(cameFrom, endNode) {
  let current = endNode;
  const path = [current];
  while (key(current) in cameFrom) {
    current = cameFrom[key(current)];
    path.push(current);
  }
  return path.reverse();
}

function countTurns(path) {
  if (path.length < 3) return 0;
  let turns = 0;
  for (let i = 2; i < path.length; i++) {
    const a = path[i - 2];
    const b = path[i - 1];
    const c = path[i];
    const d1r = b.row - a.row;
    const d1c = b.col - a.col;
    const d2r = c.row - b.row;
    const d2c = c.col - b.col;
    if (d1r !== d2r || d1c !== d2c) turns++;
  }
  return turns;
}

function computePathCost(path) {
  let total = 0;
  for (let i = 0; i < path.length; i++) {
    const node = path[i];
    total += weights[node.row][node.col];
    if (i > 0) {
      const prev = path[i - 1];
      total += Math.hypot(node.row - prev.row, node.col - prev.col) - 1;
    }
  }
  return total;
}

function pathWithTurnPenalty(path, turnPenalty = 2) {
  const turns = countTurns(path);
  return {
    turns,
    cost: computePathCost(path) + turns * turnPenalty
  };
}

async function animateStoredPath(path) {
  resetSearchStates();
  for (const node of path) {
    if ((node.row === startNode.row && node.col === startNode.col) || (node.row === goalNode.row && node.col === goalNode.col)) continue;
    grid[node.row][node.col] = PATH;
    drawGrid();
    await sleep(25);
  }
}

async function animateFinalPathAndStats(cameFrom, current, algorithmName) {
  const path = rebuildPath(cameFrom, current);
  lastRawPath = [...path];
  lastPath = [...path];
  await animateStoredPath(path);
  const metrics = pathWithTurnPenalty(path, 1.5);
  updateStats({
    explored: nodesExploredCount,
    pathLength: path.length,
    pathCost: metrics.cost,
    turns: metrics.turns,
    algorithm: algorithmName
  });
  setStatus(`${algorithmName} finished: path found.`);
  isRunning = false;
}

async function runWeightedSearch(mode) {
  resetSearchStates();
  drawGrid();
  isRunning = true;
  nodesExploredCount = 0;
  currentAlgorithmName = mode;
  setStatus(`Running ${mode}...`);

  if (mode === "DFS") {
    const stack = [startNode];
    const visited = new Set();
    const cameFrom = {};

    while (stack.length > 0) {
      const current = stack.pop();
      const currentKey = key(current);
      if (visited.has(currentKey)) continue;
      visited.add(currentKey);
      nodesExploredCount++;

      if (current.row === goalNode.row && current.col === goalNode.col) {
        await animateFinalPathAndStats(cameFrom, current, mode);
        return;
      }

      if (!(current.row === startNode.row && current.col === startNode.col)) {
        grid[current.row][current.col] = CLOSED;
      }

      for (const neighbor of getNeighbors(current).reverse()) {
        const nk = key(neighbor);
        if (!visited.has(nk)) {
          cameFrom[nk] = current;
          stack.push({ row: neighbor.row, col: neighbor.col });
          if (grid[neighbor.row][neighbor.col] === EMPTY) grid[neighbor.row][neighbor.col] = OPEN;
        }
      }

      drawGrid();
      await sleep(14);
    }
  } else if (mode === "BFS") {
    const queue = [startNode];
    const visited = new Set([key(startNode)]);
    const cameFrom = {};

    while (queue.length > 0) {
      const current = queue.shift();
      nodesExploredCount++;

      if (current.row === goalNode.row && current.col === goalNode.col) {
        await animateFinalPathAndStats(cameFrom, current, mode);
        return;
      }

      if (!(current.row === startNode.row && current.col === startNode.col)) {
        grid[current.row][current.col] = CLOSED;
      }

      for (const neighbor of getNeighbors(current)) {
        const nk = key(neighbor);
        if (!visited.has(nk)) {
          visited.add(nk);
          cameFrom[nk] = current;
          queue.push({ row: neighbor.row, col: neighbor.col });
          if (grid[neighbor.row][neighbor.col] === EMPTY) grid[neighbor.row][neighbor.col] = OPEN;
        }
      }

      drawGrid();
      await sleep(14);
    }
  } else {
    const openSet = [startNode];
    const cameFrom = {};
    const gScore = {};
    const fScore = {};

    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        gScore[`${r},${c}`] = Infinity;
        fScore[`${r},${c}`] = Infinity;
      }
    }

    gScore[key(startNode)] = 0;
    fScore[key(startNode)] = heuristic(startNode, goalNode);

    while (openSet.length > 0) {
      openSet.sort((a, b) => fScore[key(a)] - fScore[key(b)]);
      const current = openSet.shift();
      nodesExploredCount++;

      if (current.row === goalNode.row && current.col === goalNode.col) {
        await animateFinalPathAndStats(cameFrom, current, mode);
        return;
      }

      if (!(current.row === startNode.row && current.col === startNode.col)) {
        grid[current.row][current.col] = CLOSED;
      }

      for (const neighbor of getNeighbors(current)) {
        const prev = cameFrom[key(current)];
        let turnPenalty = 0;

        if (prev) {
          const dx1 = current.col - prev.col;
          const dy1 = current.row - prev.row;
          const dx2 = neighbor.col - current.col;
          const dy2 = neighbor.row - current.row;
          if (dx1 !== dx2 || dy1 !== dy2) turnPenalty = 0.35;
        }

        const tentativeG = gScore[key(current)] + neighbor.moveCost + turnPenalty;
        if (tentativeG < gScore[key(neighbor)]) {
          cameFrom[key(neighbor)] = { row: current.row, col: current.col };
          gScore[key(neighbor)] = tentativeG;
          fScore[key(neighbor)] = tentativeG + heuristic(neighbor, goalNode);

          if (!openSet.some((n) => n.row === neighbor.row && n.col === neighbor.col)) {
            openSet.push({ row: neighbor.row, col: neighbor.col });
            if (grid[neighbor.row][neighbor.col] === EMPTY) grid[neighbor.row][neighbor.col] = OPEN;
          }
        }
      }

      drawGrid();
      await sleep(12);
    }
  }

  setStatus(`${mode} finished: no path found.`);
  isRunning = false;
}

function hasLineOfSight(a, b) {
  let x0 = a.col;
  let y0 = a.row;
  const x1 = b.col;
  const y1 = b.row;
  const dx = Math.abs(x1 - x0);
  const dy = Math.abs(y1 - y0);
  const sx = x0 < x1 ? 1 : -1;
  const sy = y0 < y1 ? 1 : -1;
  let err = dx - dy;

  while (true) {
    if (!inBounds(y0, x0) || grid[y0][x0] === WALL) return false;
    if (x0 === x1 && y0 === y1) break;
    const e2 = err * 2;
    if (e2 > -dy) {
      err -= dy;
      x0 += sx;
    }
    if (e2 < dx) {
      err += dx;
      y0 += sy;
    }
  }
  return true;
}

function smoothPath(path) {
  if (path.length < 3) return [...path];
  const smoothed = [path[0]];
  let i = 0;
  while (i < path.length - 1) {
    let j = path.length - 1;
    while (j > i + 1) {
      if (hasLineOfSight(path[i], path[j])) break;
      j--;
    }
    smoothed.push(path[j]);
    i = j;
  }
  return smoothed;
}

async function optimizePath() {
  if (isRunning) return;
  if (!lastPath.length) {
    setStatus("Run a search first.");
    return;
  }

  isRunning = true;
  setStatus("Optimizing route...");
  let workingPath = [...lastPath];

  for (let i = 0; i < 4; i++) {
    workingPath = smoothPath(workingPath);
    lastPath = [...workingPath];
    await animateStoredPath(workingPath);
    const metrics = pathWithTurnPenalty(workingPath, 1.5);
    updateStats({
      explored: nodesExploredCount,
      pathLength: workingPath.length,
      pathCost: metrics.cost,
      turns: metrics.turns,
      algorithm: `${currentAlgorithmName} + Smoothing`
    });
    await sleep(180);
  }

  setStatus("Optimization complete.");
  isRunning = false;
}

async function animateRobotAlongPath(path = lastPath) {
  if (isRunning || !path.length) return;
  isRunning = true;
  setStatus("Animating robot...");

  for (let i = 0; i < path.length; i++) {
    drawGrid(path[i]);
    if (i > 0) {
      const prev = path[i - 1];
      const current = path[i];
      ctx.beginPath();
      ctx.moveTo(prev.col * cellSize + cellSize / 2, prev.row * cellSize + cellSize / 2);
      ctx.lineTo(current.col * cellSize + cellSize / 2, current.row * cellSize + cellSize / 2);
      ctx.strokeStyle = "#111827";
      ctx.lineWidth = 3;
      ctx.stroke();
      ctx.lineWidth = 1;
    }
    await sleep(80);
  }

  drawGrid();
  setStatus("Robot animation complete.");
  isRunning = false;
}

function randomWalls(density = 0.22) {
  if (isRunning) return;
  clearPathOnly();
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if ((r === startNode.row && c === startNode.col) || (r === goalNode.row && c === goalNode.col)) continue;
      if (Math.random() < density) {
        grid[r][c] = WALL;
        weights[r][c] = 1;
      } else if (grid[r][c] === WALL) {
        grid[r][c] = EMPTY;
      }
    }
  }
  drawGrid();
  setStatus("Random obstacles generated.");
}

async function compareAlgorithms() {
  if (isRunning) return;
  setStatus("Comparing DFS then A*...");
  await runDFS();
  await sleep(450);
  await runAStar();
}

function generateSurface() {
  gradientSurface = [];
  for (let y = 0; y < gradientCanvas.height; y++) {
    const row = [];
    for (let x = 0; x < gradientCanvas.width; x++) {
      const nx = x / 90;
      const ny = y / 90;
      const val = Math.sin(nx) * Math.cos(ny) + 0.45 * Math.sin(1.8 * nx) + 0.35 * Math.cos(2.4 * ny);
      row.push(val);
    }
    gradientSurface.push(row);
  }
}

function drawSurface() {
  const img = gctx.createImageData(gradientCanvas.width, gradientCanvas.height);
  for (let y = 0; y < gradientCanvas.height; y++) {
    for (let x = 0; x < gradientCanvas.width; x++) {
      const val = gradientSurface[y][x];
      const mapped = Math.floor((val + 2) * 60);
      const i = (y * gradientCanvas.width + x) * 4;
      img.data[i] = mapped;
      img.data[i + 1] = 100;
      img.data[i + 2] = 255 - mapped;
      img.data[i + 3] = 255;
    }
  }
  gctx.putImageData(img, 0, 0);

  if (gradientTrace.length > 1) {
    gctx.beginPath();
    gctx.moveTo(gradientTrace[0].x, gradientTrace[0].y);
    for (let i = 1; i < gradientTrace.length; i++) {
      gctx.lineTo(gradientTrace[i].x, gradientTrace[i].y);
    }
    gctx.strokeStyle = "rgba(255,255,255,0.85)";
    gctx.lineWidth = 2;
    gctx.stroke();
  }

  gctx.fillStyle = "#ffffff";
  gctx.beginPath();
  gctx.arc(gradientPoint.x, gradientPoint.y, 5, 0, Math.PI * 2);
  gctx.fill();
}

function surfaceGradient(x, y) {
  const eps = 1;
  const x1 = Math.min(Math.floor(x + eps), gradientCanvas.width - 1);
  const x0 = Math.max(Math.floor(x - eps), 0);
  const y1 = Math.min(Math.floor(y + eps), gradientCanvas.height - 1);
  const y0 = Math.max(Math.floor(y - eps), 0);
  const dx = gradientSurface[Math.floor(y)][x1] - gradientSurface[Math.floor(y)][x0];
  const dy = gradientSurface[y1][Math.floor(x)] - gradientSurface[y0][Math.floor(x)];
  return { dx, dy };
}

async function runGradientDescent() {
  if (isRunning) return;
  isRunning = true;
  setStatus("Running gradient descent...");
  gradientPoint = {
    x: Math.floor(Math.random() * (gradientCanvas.width - 40)) + 20,
    y: Math.floor(Math.random() * (gradientCanvas.height - 40)) + 20
  };
  gradientTrace = [{ ...gradientPoint }];

  for (let i = 0; i < 120; i++) {
    const { dx, dy } = surfaceGradient(gradientPoint.x, gradientPoint.y);
    gradientPoint.x -= dx * 5;
    gradientPoint.y -= dy * 5;
    gradientPoint.x = Math.max(0, Math.min(gradientCanvas.width - 1, gradientPoint.x));
    gradientPoint.y = Math.max(0, Math.min(gradientCanvas.height - 1, gradientPoint.y));
    gradientTrace.push({ ...gradientPoint });
    drawSurface();
    await sleep(24);
  }

  setStatus("Gradient descent complete.");
  isRunning = false;
}

async function runAStar() {
  await runWeightedSearch("Weighted A*");
}

async function runBFS() {
  await runWeightedSearch("BFS");
}

async function runDFS() {
  await runWeightedSearch("DFS");
}

function setLiveMode(next) {
  liveMode = next;
  const btn = document.getElementById("live-mode");
  btn.setAttribute("aria-pressed", String(liveMode));
  btn.textContent = `Live Replan: ${liveMode ? "On" : "Off"}`;
  setStatus(liveMode ? "Live replanning enabled." : "Live replanning disabled.");
}

// Event listeners

document.getElementById("tool-start").addEventListener("click", () => setTool("start", "Place Start"));
document.getElementById("tool-goal").addEventListener("click", () => setTool("goal", "Place Goal"));
document.getElementById("tool-wall").addEventListener("click", () => setTool("wall", "Place Walls"));
document.getElementById("tool-erase").addEventListener("click", () => setTool("erase", "Erase"));
document.getElementById("tool-weight").addEventListener("click", () => setTool("weight", "Paint Weight"));
document.getElementById("run-astar").addEventListener("click", () => !isRunning && runAStar());
document.getElementById("run-bfs").addEventListener("click", () => !isRunning && runBFS());
document.getElementById("run-dfs").addEventListener("click", () => !isRunning && runDFS());
document.getElementById("optimize-path").addEventListener("click", () => optimizePath());
document.getElementById("animate-robot").addEventListener("click", () => animateRobotAlongPath());
document.getElementById("run-gradient").addEventListener("click", () => runGradientDescent());
document.getElementById("generate-maze").addEventListener("click", () => randomWalls());
document.getElementById("clear-path").addEventListener("click", () => clearPathOnly());
document.getElementById("clear-grid").addEventListener("click", () => {
  if (isRunning) return;
  createGrid();
  drawGrid();
  updateStats();
  setStatus("Grid cleared.");
});
document.getElementById("compare-mode").addEventListener("click", () => compareAlgorithms());
document.getElementById("live-mode").addEventListener("click", () => setLiveMode(!liveMode));

gridCanvas.addEventListener("click", (event) => {
  const { row, col } = getCellFromMouse(event);
  applyToolAtCell(row, col);
});

gridCanvas.addEventListener("mousedown", (event) => {
  isMouseDown = true;
  const { row, col } = getCellFromMouse(event);
  applyToolAtCell(row, col);
});

gridCanvas.addEventListener("mousemove", (event) => {
  if (!isMouseDown) return;
  const { row, col } = getCellFromMouse(event);
  if (["wall", "erase", "weight"].includes(currentTool)) {
    applyToolAtCell(row, col);
  }
});

window.addEventListener("mouseup", () => {
  isMouseDown = false;
});

window.addEventListener("keydown", (event) => {
  const k = event.key.toLowerCase();
  if (k === "1") setTool("start", "Place Start");
  if (k === "2") setTool("goal", "Place Goal");
  if (k === "3") setTool("wall", "Place Walls");
  if (k === "4") setTool("erase", "Erase");
  if (k === "5") setTool("weight", "Paint Weight");
  if (k === "a" && !isRunning) runAStar();
  if (k === "b" && !isRunning) runBFS();
  if (k === "d" && !isRunning) runDFS();
  if (k === "o" && !isRunning) optimizePath();
  if (k === "r" && !isRunning) animateRobotAlongPath();
  if (k === "g" && !isRunning) runGradientDescent();
});

createGrid();
generateSurface();
drawGrid();
drawSurface();
updateStats();
setTool("wall", "Place Walls");
setLiveMode(false);
setStatus("Ready");
